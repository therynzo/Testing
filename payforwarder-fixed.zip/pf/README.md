# PayForwarder

Native Android (Kotlin, Jetpack Compose, Material 3) SMS forwarder for **bKash** and **Nagad** payment confirmations. Designed exclusively for personal sideloading on your own device—no ads, no analytics, and no Firebase.

## Features

- **Priority SMS Receiver (`priority = 999`)**: Uses `Telephony.Sms.Intents.getMessagesFromIntent` to capture incoming SMS across **both SIM slots**, automatically joining multipart segments from the same sender.
- **Strict Sender Filtering**: Only SMS whose sender contains an allowed keyword (default: `bkash`, `nagad`, case-insensitive, editable in Settings) are processed. Other messages are ignored and never stored or transmitted.
- **Reliable Local-First Queue**: Every matching SMS is persisted to a local **Room** database before sending, deduplicated by `sender + text + timestamp`.
- **Automatic Retries**: **WorkManager** retries `PENDING` items with exponential backoff when offline or on transient server failures, automatically resuming on **device boot** (`BOOT_COMPLETED`) and when **network connectivity returns**.
- **Auth Guard**: HTTP `401` responses mark the entry as `AUTH 401` (`FAILED_AUTH`) and trigger a high-priority notification (`"Wrong secret, check settings"`) instead of retrying endlessly.
- **Keep-Alive Watcher**: Toggleable foreground service (`Watching for payments`) plus guided battery optimization exemption (`REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`).
- **Secure Secret Storage**: Webhook URL and settings are stored in **DataStore**; the `X-Webhook-Secret` value is encrypted via **Android Keystore** (`AES/GCM/NoPadding`).

## Webhook Contract

For each matching SMS, PayForwarder sends an HTTP `POST` (15s timeout, plain `http://` supported via `usesCleartextTraffic="true"`):

- **Headers**:
  - `Content-Type: application/json`
  - `X-Webhook-Secret: <your-secret>`
- **Body**:
  ```json
  {"from":"bKash","text":"You have received Tk 1,500.00 from 017XXXXXXXX. Ref ... TrxID ..."}
  ```
- **Expected Success**: HTTP `200` (e.g. `{"ok":true,"status":"saved"}`).
- **Test Button**: Sends `{"from":"bKash","text":"TEST"}` and displays the raw HTTP status code and response body.

---

## Building the APK in Android Studio

1. **Open the Project**:
   - Launch **Android Studio** (Ladybug / Meerkat or newer).
   - Select **File → Open** and choose the root `PayForwarder` directory.
   - Wait for Gradle sync to finish (requires JDK 17+ and Android SDK Platform 34).
2. **Verify SDK Platforms**:
   - Open **Tools → SDK Manager** and confirm **Android 14.0 (API 34)** is installed.
3. **Build the Debug APK**:
   - From the top menu, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   - Or run from the terminal in the project root:
     ```bash
     ./gradlew :app:assembleDebug
     ```
4. **Locate the APK**:
   - The generated APK will be at:
     ```
     app/build/outputs/apk/debug/app-debug.apk
     ```

### Building via GitHub Actions

Every push runs `.github/workflows/build.yml`, executes unit tests, builds `app-debug.apk`, and uploads it under the workflow run's **Artifacts** section as `app-debug`.

---

## Sideloading onto Your Android Phone

1. **Transfer the APK**:
   - Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone via USB, Google Drive, Telegram Saved Messages, or ADB (`adb install -r app/build/outputs/apk/debug/app-debug.apk`).
2. **Allow Unknown Apps**:
   - Tap `app-debug.apk` in your phone's Files app.
   - If prompted, tap **Settings** → enable **Allow from this source** for your file manager, then tap **Install**.
3. **Android 13 / 14 Restricted Settings Note (Important for SMS)**:
   - Because PayForwarder is sideloaded and requests `RECEIVE_SMS` / `READ_SMS`, Android 13+ may block SMS permission prompts until you unlock Restricted Settings:
     - Open **Settings → Apps → PayForwarder → ⋮ (top-right menu) → Allow restricted settings** (confirm with fingerprint/PIN).
4. **First-Launch Setup**:
   - Open **PayForwarder** and tap **Grant Permissions** (SMS + Notifications).
   - Tap **Disable Battery Optimization** and allow unrestricted background operation.
   - Go to **Settings**, enter your **Webhook URL** (e.g., `http://123.123.123.123:25570/webhook/sms`) and **Webhook Secret**, tap **Send Test** to verify HTTP `200`, then tap **Save Settings**.

---

## Connect to the Sillyhosting bot

In the app, open **Settings** and fill in:

- **Webhook URL:** `http://YOUR_IP:YOUR_PORT/webhook/sms` (the same IP and port as your bot dashboard)
- **Secret:** the exact value of `PAYMENT_WEBHOOK_SECRET` in the bot's `.env`
- **Allowed senders:** `bkash, nagad`

Press **Send test**. A working connection shows **HTTP 200** with `"status":"ignored"` (the bot ignores the word TEST on purpose).
`HTTP 401` means the secret is wrong. A timeout means the IP, port or firewall is wrong.

## Building the APK without AI Studio

Push this folder to a GitHub repository. The workflow in `.github/workflows/build.yml` runs the unit tests and builds `app-debug.apk`.
Download it from the **Actions** tab, in the finished run under **Artifacts**.
`debug.keystore` is not needed: if it is missing the build uses the standard Android debug key.
