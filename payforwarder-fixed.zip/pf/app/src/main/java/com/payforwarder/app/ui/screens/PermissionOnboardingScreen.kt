package com.payforwarder.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.payforwarder.app.R
import com.payforwarder.app.ui.state.SystemHealthState
import com.payforwarder.app.ui.theme.LocalPayForwarderColors

@Composable
fun PermissionOnboardingScreen(
    health: SystemHealthState,
    contentPadding: PaddingValues,
    onRequestPermissions: () -> Unit,
    onRequestBatteryExemption: () -> Unit,
    onContinue: () -> Unit
) {
    Box(
        contentAlignment = Alignment.TopCenter,
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Security,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Text(
                text = stringResource(R.string.permissions_onboarding_title),
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = stringResource(R.string.permissions_onboarding_subtitle),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            PermissionExplainCard(
                icon = Icons.Rounded.Sms,
                title = "SMS Access (RECEIVE_SMS & READ_SMS)",
                description = "Reads incoming SMS on both SIMs to detect bKash and Nagad confirmations. Non-matching personal messages are never saved or uploaded.",
                granted = health.hasSmsPermission
            )

            PermissionExplainCard(
                icon = Icons.Rounded.NotificationsActive,
                title = "Notifications (POST_NOTIFICATIONS)",
                description = "Shows the persistent \"Watching for payments\" watcher status and immediately alerts you if your webhook secret returns HTTP 401.",
                granted = health.hasNotificationPermission
            )

            PermissionExplainCard(
                icon = Icons.Rounded.BatteryChargingFull,
                title = stringResource(R.string.battery_optimization_title),
                description = stringResource(R.string.battery_optimization_body),
                granted = health.isBatteryOptimizationExempt
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (!health.hasSmsPermission || !health.hasNotificationPermission) {
                Button(
                    onClick = onRequestPermissions,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                        .testTag("onboarding_grant_permissions_button")
                ) {
                    Text(stringResource(R.string.grant_permissions_button))
                }
            }

            if (!health.isBatteryOptimizationExempt) {
                OutlinedButton(
                    onClick = onRequestBatteryExemption,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                        .testTag("onboarding_battery_exempt_button")
                ) {
                    Text(stringResource(R.string.exempt_battery_button))
                }
            }

            if (health.hasSmsPermission && health.isBatteryOptimizationExempt) {
                Button(
                    onClick = onContinue,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                        .testTag("onboarding_continue_button")
                ) {
                    Text(stringResource(R.string.continue_button))
                }
            } else {
                TextButton(
                    onClick = onContinue,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .heightIn(min = 48.dp)
                        .testTag("onboarding_skip_button")
                ) {
                    Text("Continue to Dashboard anyway")
                }
            }
        }
    }
}

@Composable
private fun PermissionExplainCard(
    icon: ImageVector,
    title: String,
    description: String,
    granted: Boolean
) {
    val extended = LocalPayForwarderColors.current
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                shape = CircleShape,
                color = if (granted) extended.emeraldContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (granted) Icons.Rounded.CheckCircle else icon,
                        contentDescription = null,
                        tint = if (granted) extended.emerald else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    if (granted) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Granted",
                            style = MaterialTheme.typography.labelSmall,
                            color = extended.emerald
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
