package com.payforwarder.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.payforwarder.app.ui.components.AtmosphereBackground
import com.payforwarder.app.ui.screens.DashboardScreen
import com.payforwarder.app.ui.screens.PermissionOnboardingScreen
import com.payforwarder.app.ui.screens.SettingsScreen
import com.payforwarder.app.ui.state.MainUiState
import com.payforwarder.app.ui.state.MainViewModel
import com.payforwarder.app.ui.theme.LocalPayForwarderColors
import kotlinx.serialization.Serializable

@Serializable
object DashboardRoute

@Serializable
object SettingsRoute

@Composable
fun PayForwarderRoot(
    uiState: MainUiState,
    viewModel: MainViewModel,
    openSettingsInitially: Boolean,
    onRequestPermissions: () -> Unit,
    onRequestBatteryExemption: () -> Unit
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val showOnboarding = !uiState.settings.onboardingCompleted && !uiState.health.hasSmsPermission

    LaunchedEffect(uiState.statusBannerMessage) {
        val message = uiState.statusBannerMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        viewModel.clearBannerMessage()
    }

    LaunchedEffect(openSettingsInitially, showOnboarding) {
        if (openSettingsInitially && !showOnboarding) {
            navController.navigate(SettingsRoute) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    AtmosphereBackground {
        val backStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = backStackEntry?.destination

        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = {
                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier.navigationBarsPadding()
                )
            }
        ) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize()) {
                if (showOnboarding) {
                    PermissionOnboardingScreen(
                        health = uiState.health,
                        contentPadding = innerPadding,
                        onRequestPermissions = onRequestPermissions,
                        onRequestBatteryExemption = onRequestBatteryExemption,
                        onContinue = { viewModel.markOnboardingComplete() }
                    )
                } else {
                    NavHost(
                        navController = navController,
                        startDestination = DashboardRoute
                    ) {
                        composable<DashboardRoute> {
                            DashboardScreen(
                                uiState = uiState,
                                contentPadding = innerPadding,
                                onRequestSmsPermission = onRequestPermissions,
                                onRequestBatteryExemption = onRequestBatteryExemption,
                                onOpenSettings = {
                                    navController.navigate(SettingsRoute) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                onSelectSms = { viewModel.selectSms(it) },
                                onRetrySms = { viewModel.retrySms(it) }
                            )
                        }
                        composable<SettingsRoute> {
                            SettingsScreen(
                                uiState = uiState,
                                contentPadding = innerPadding,
                                onSaveSettings = { url, secret, senders, fg ->
                                    viewModel.saveSettings(url, secret, senders, fg)
                                },
                                onToggleForegroundService = { viewModel.toggleForegroundService(it) },
                                onSendTest = { url, secret ->
                                    viewModel.sendTestWebhook(url, secret)
                                },
                                onRequestBatteryExemption = onRequestBatteryExemption,
                                onClearHistory = { viewModel.clearHistory() }
                            )
                        }
                    }

                    val isDashboard = currentDestination?.hasRoute<DashboardRoute>() ?: true
                    val isSettings = currentDestination?.hasRoute<SettingsRoute>() ?: false

                    FloatingPillBottomBar(
                        isDashboardSelected = isDashboard,
                        isSettingsSelected = isSettings,
                        onSelectDashboard = {
                            navController.navigate(DashboardRoute) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        onSelectSettings = {
                            navController.navigate(SettingsRoute) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(bottom = 14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FloatingPillBottomBar(
    isDashboardSelected: Boolean,
    isSettingsSelected: Boolean,
    onSelectDashboard: () -> Unit,
    onSelectSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalPayForwarderColors.current

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = extended.navPillBackground,
        shadowElevation = 12.dp
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            PillNavItem(
                icon = Icons.Rounded.Dashboard,
                label = "Dashboard",
                selected = isDashboardSelected,
                onClick = onSelectDashboard,
                modifier = Modifier.testTag("nav_dashboard")
            )
            PillNavItem(
                icon = Icons.Rounded.Settings,
                label = "Settings",
                selected = isSettingsSelected,
                onClick = onSelectSettings,
                modifier = Modifier.testTag("nav_settings")
            )
        }
    }
}

@Composable
private fun PillNavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalPayForwarderColors.current
    val bg = if (selected) extended.navPillSelected else Color.Transparent
    val fg = if (selected) extended.navPillSelectedContent else extended.navPillUnselectedContent

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = fg,
            modifier = Modifier.size(19.dp)
        )
        Spacer(modifier = Modifier.width(7.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = fg
        )
    }
}
