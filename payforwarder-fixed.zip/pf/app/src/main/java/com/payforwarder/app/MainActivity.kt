package com.payforwarder.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.payforwarder.app.notifications.NotificationHelper
import com.payforwarder.app.ui.PayForwarderRoot
import com.payforwarder.app.ui.state.MainViewModel
import com.payforwarder.app.ui.theme.PayForwarderTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.Factory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val openSettingsInitially = intent?.getBooleanExtra(
            NotificationHelper.EXTRA_OPEN_SETTINGS,
            false
        ) ?: false

        setContent {
            PayForwarderTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                val permissionsLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    viewModel.refreshSystemHealth()
                }

                LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
                    viewModel.refreshSystemHealth()
                }

                PayForwarderRoot(
                    uiState = uiState,
                    viewModel = viewModel,
                    openSettingsInitially = openSettingsInitially,
                    onRequestPermissions = {
                        val permissions = buildList {
                            add(Manifest.permission.RECEIVE_SMS)
                            add(Manifest.permission.READ_SMS)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }.toTypedArray()
                        permissionsLauncher.launch(permissions)
                    },
                    onRequestBatteryExemption = {
                        requestBatteryOptimizationExemption()
                    }
                )
            }
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryOptimizationExemption() {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
        }
        runCatching { startActivity(intent) }
            .onFailure {
                val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                runCatching { startActivity(fallback) }
            }
    }
}
