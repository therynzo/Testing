package com.payforwarder.app.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class WebhookResult {
    data class Success(val code: Int, val body: String) : WebhookResult()
    data class Unauthorized(val code: Int, val body: String) : WebhookResult()
    data class HttpFailure(val code: Int, val body: String, val isRetryable: Boolean) : WebhookResult()
    data class NetworkFailure(val message: String) : WebhookResult()
    data class InvalidConfig(val reason: String) : WebhookResult()
}

data class TestWebhookResponse(
    val statusCode: Int?,
    val body: String,
    val isSuccess: Boolean,
    val errorMessage: String? = null
)

class WebhookClient(
    private val client: OkHttpClient = defaultOkHttpClient()
) {
    suspend fun sendSms(
        webhookUrl: String,
        secret: String,
        from: String,
        text: String
    ): WebhookResult = withContext(Dispatchers.IO) {
        val parsedUrl = webhookUrl.trim().toHttpUrlOrNull()
        if (parsedUrl == null || (parsedUrl.scheme != "http" && parsedUrl.scheme != "https")) {
            return@withContext WebhookResult.InvalidConfig("Invalid or empty webhook URL")
        }

        val jsonPayload = JSONObject().apply {
            put("from", from)
            put("text", text)
        }.toString()

        val request = Request.Builder()
            .url(parsedUrl)
            .header("Content-Type", "application/json")
            .header("X-Webhook-Secret", secret)
            .post(jsonPayload.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val code = response.code
                val body = response.body?.string().orEmpty()
                when {
                    code == 200 -> WebhookResult.Success(code, body)
                    code == 401 -> WebhookResult.Unauthorized(code, body)
                    code == 408 || code == 429 || code in 500..599 ->
                        WebhookResult.HttpFailure(code, body, isRetryable = true)
                    else ->
                        WebhookResult.HttpFailure(code, body, isRetryable = false)
                }
            }
        } catch (e: IOException) {
            WebhookResult.NetworkFailure(e.message ?: e.javaClass.simpleName)
        }
    }

    suspend fun sendTest(webhookUrl: String, secret: String): TestWebhookResponse {
        return when (val result = sendSms(webhookUrl, secret, from = "bKash", text = "TEST")) {
            is WebhookResult.Success -> TestWebhookResponse(
                statusCode = result.code,
                body = result.body,
                isSuccess = true
            )
            is WebhookResult.Unauthorized -> TestWebhookResponse(
                statusCode = result.code,
                body = result.body,
                isSuccess = false,
                errorMessage = "Wrong secret (HTTP 401)"
            )
            is WebhookResult.HttpFailure -> TestWebhookResponse(
                statusCode = result.code,
                body = result.body,
                isSuccess = false,
                errorMessage = "Server returned HTTP ${result.code}"
            )
            is WebhookResult.NetworkFailure -> TestWebhookResponse(
                statusCode = null,
                body = "",
                isSuccess = false,
                errorMessage = result.message
            )
            is WebhookResult.InvalidConfig -> TestWebhookResponse(
                statusCode = null,
                body = "",
                isSuccess = false,
                errorMessage = result.reason
            )
        }
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private const val TIMEOUT_SECONDS = 15L

        fun defaultOkHttpClient(): OkHttpClient {
            return OkHttpClient.Builder()
                .connectTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .callTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .build()
        }
    }
}
