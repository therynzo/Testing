package com.payforwarder.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.SimCard
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.payforwarder.app.data.local.ForwardedSmsEntity
import com.payforwarder.app.domain.SmsStatus
import com.payforwarder.app.ui.state.MainUiState
import com.payforwarder.app.ui.theme.JetBrainsMono
import com.payforwarder.app.ui.theme.LocalPayForwarderColors
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val TimeShortFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("hh:mm a · MMM d").withZone(ZoneId.systemDefault())

private val TimeFullFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault())

@Composable
fun AtmosphereBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val extended = LocalPayForwarderColors.current
    val base = MaterialTheme.colorScheme.background

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(base)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(extended.peachGlow.copy(alpha = 0.65f), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.14f),
                        radius = size.width * 0.72f
                    ),
                    radius = size.width * 0.72f,
                    center = Offset(size.width * 0.85f, size.height * 0.14f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(extended.periwinkleGlow.copy(alpha = 0.6f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.28f),
                        radius = size.width * 0.75f
                    ),
                    radius = size.width * 0.75f,
                    center = Offset(size.width * 0.15f, size.height * 0.28f)
                )
            }
    ) {
        content()
    }
}

@Composable
fun HeroStatusCard(
    uiState: MainUiState,
    onRequestSmsPermission: () -> Unit,
    onRequestBatteryExemption: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalPayForwarderColors.current
    val isActive = uiState.isFullyActive

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val cardBrush = if (isActive) {
        Brush.linearGradient(
            colors = listOf(
                MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                extended.periwinkleSurface.copy(alpha = 0.92f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                extended.peachSurface.copy(alpha = 0.95f)
            )
        )
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("hero_status_card"),
        shape = RoundedCornerShape(26.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .background(cardBrush)
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .alpha(if (isActive) pulseAlpha else 1f)
                            .clip(CircleShape)
                            .background(if (isActive) extended.emerald else extended.amber)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isActive) "Active" else "Action Needed",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isActive) extended.emeraldContainer else extended.amberContainer
                ) {
                    Text(
                        text = if (isActive) {
                            if (uiState.settings.foregroundServiceEnabled) "Watcher On" else "Receiver Ready"
                        } else {
                            "${uiState.missingRequirements.size} Issue${if (uiState.missingRequirements.size > 1) "s" else ""}"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isActive) extended.emerald else extended.amber,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isActive) {
                Text(
                    text = "Listening on both SIM slots for ${uiState.settings.allowedSenders.joinToString(", ").ifBlank { "bKash, Nagad" }}. Matching payments are queued locally and delivered to your server.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    text = "Fix the items below so no payment SMS is missed:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                uiState.missingRequirements.forEach { issue ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = extended.amber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = issue,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (!uiState.health.hasSmsPermission || !uiState.health.hasNotificationPermission) {
                        Button(
                            onClick = onRequestSmsPermission,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("fix_permissions_button")
                        ) {
                            Text("Grant Permissions")
                        }
                    } else if (!uiState.health.isBatteryOptimizationExempt) {
                        Button(
                            onClick = onRequestBatteryExemption,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("fix_battery_button")
                        ) {
                            Text("Exempt Battery")
                        }
                    } else if (!uiState.settings.isWebhookConfigured) {
                        Button(
                            onClick = onOpenSettings,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("fix_webhook_button")
                        ) {
                            Text("Configure Webhook")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CountersRow(
    sentToday: Int,
    pending: Int,
    failed: Int,
    modifier: Modifier = Modifier
) {
    val extended = LocalPayForwarderColors.current

    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        MetricCard(
            title = "Sent Today",
            count = sentToday,
            containerBrush = Brush.linearGradient(
                listOf(
                    MaterialTheme.colorScheme.surface,
                    extended.emeraldContainer.copy(alpha = 0.7f)
                )
            ),
            accentColor = extended.emerald,
            modifier = Modifier
                .weight(1f)
                .testTag("counter_sent_today")
        )
        MetricCard(
            title = "Pending",
            count = pending,
            containerBrush = Brush.linearGradient(
                listOf(
                    MaterialTheme.colorScheme.surface,
                    extended.peachSurface
                )
            ),
            accentColor = extended.amber,
            modifier = Modifier
                .weight(1f)
                .testTag("counter_pending")
        )
        MetricCard(
            title = "Failed",
            count = failed,
            containerBrush = Brush.linearGradient(
                listOf(
                    MaterialTheme.colorScheme.surface,
                    extended.crimsonContainer.copy(alpha = 0.75f)
                )
            ),
            accentColor = extended.crimson,
            modifier = Modifier
                .weight(1f)
                .testTag("counter_failed")
        )
    }
}

@Composable
private fun MetricCard(
    title: String,
    count: Int,
    containerBrush: Brush,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .background(containerBrush)
                .padding(horizontal = 14.dp, vertical = 16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.displaySmall,
                color = accentColor
            )
        }
    }
}

@Composable
fun SmsHistoryRow(
    item: ForwardedSmsEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val preview = item.text.replace('\n', ' ').let { clean ->
        if (clean.length > 60) clean.take(60) + "..." else clean
    }
    val formattedTime = TimeShortFormatter.format(Instant.ofEpochMilli(item.receivedAt))

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("sms_item_${item.id}"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Sms,
                                contentDescription = "Sender",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.sender,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (item.simSlot != null) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.SimCard,
                                            contentDescription = "SIM slot ${item.simSlot}",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(11.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = "SIM ${item.simSlot}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                StatusChip(status = item.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = preview,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = JetBrainsMono,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun StatusChip(
    status: SmsStatus,
    modifier: Modifier = Modifier
) {
    val extended = LocalPayForwarderColors.current
    val (label, fg, bg, icon) = when (status) {
        SmsStatus.SENT -> Quad("SENT", extended.emerald, extended.emeraldContainer, Icons.Rounded.CheckCircle)
        SmsStatus.PENDING -> Quad("PENDING", extended.amber, extended.amberContainer, Icons.Rounded.Schedule)
        SmsStatus.FAILED -> Quad("FAILED", extended.crimson, extended.crimsonContainer, Icons.Rounded.ErrorOutline)
        SmsStatus.FAILED_AUTH -> Quad("AUTH 401", extended.crimson, extended.crimsonContainer, Icons.Rounded.ErrorOutline)
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = bg
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = fg,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = fg
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmsDetailBottomSheet(
    item: ForwardedSmsEntity,
    onDismiss: () -> Unit,
    onRetry: (Long) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.sender,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    val simLabel = item.simSlot?.let { "SIM $it" } ?: "SIM Unknown"
                    Text(
                        text = "$simLabel · ${TimeFullFormatter.format(Instant.ofEpochMilli(item.receivedAt))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatusChip(status = item.status)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Full SMS Content",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                SelectionContainer {
                    Text(
                        text = item.text,
                        style = MaterialTheme.typography.bodyLarge.copy(fontFamily = JetBrainsMono),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .padding(14.dp)
                            .testTag("detail_full_sms_text")
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Spacer(modifier = Modifier.height(12.dp))

            DetailMetaRow(label = "Attempts", value = item.attemptCount.toString())
            item.lastHttpCode?.let {
                DetailMetaRow(label = "Last HTTP Status", value = it.toString())
            }
            item.sentAt?.let {
                DetailMetaRow(
                    label = "Delivered At",
                    value = TimeFullFormatter.format(Instant.ofEpochMilli(it))
                )
            }
            item.lastError?.let {
                DetailMetaRow(label = "Last Error", value = it)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = { copySmsToClipboard(context, item.text) },
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("detail_copy_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy")
                }

                Button(
                    onClick = { onRetry(item.id) },
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("detail_retry_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Retry")
                }
            }
        }
    }
}

@Composable
private fun DetailMetaRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun copySmsToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(ClipboardManager::class.java) ?: return
    manager.setPrimaryClip(ClipData.newPlainText("Payment SMS", text))
    Toast.makeText(context, "SMS copied", Toast.LENGTH_SHORT).show()
}
