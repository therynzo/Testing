package com.payforwarder.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.payforwarder.app.domain.SenderFilter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "payforwarder_settings"
)

data class AppSettings(
    val webhookUrl: String = "",
    val webhookSecret: String = "",
    val allowedSendersRaw: String = SenderFilter.DEFAULT_ALLOWED_SENDERS_RAW,
    val foregroundServiceEnabled: Boolean = true,
    val onboardingCompleted: Boolean = false
) {
    val allowedSenders: List<String>
        get() = SenderFilter.parseAllowedSenders(allowedSendersRaw)

    val isWebhookConfigured: Boolean
        get() {
            val trimmed = webhookUrl.trim()
            return (trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true)) &&
                trimmed.length > 8
        }
}

class SettingsRepository(
    context: Context,
    private val secretStore: SecretStore
) {
    private val dataStore = context.applicationContext.settingsDataStore
    private val secretState = MutableStateFlow(secretStore.getSecret())

    val settingsFlow: Flow<AppSettings> = combine(
        dataStore.data,
        secretState
    ) { prefs, secret ->
        AppSettings(
            webhookUrl = prefs[KEY_WEBHOOK_URL] ?: "",
            webhookSecret = secret,
            allowedSendersRaw = prefs[KEY_ALLOWED_SENDERS] ?: SenderFilter.DEFAULT_ALLOWED_SENDERS_RAW,
            foregroundServiceEnabled = prefs[KEY_FOREGROUND_SERVICE] ?: true,
            onboardingCompleted = prefs[KEY_ONBOARDING_COMPLETED] ?: false
        )
    }

    suspend fun getCurrentSettings(): AppSettings = settingsFlow.first()

    suspend fun updateSettings(
        webhookUrl: String,
        webhookSecret: String,
        allowedSendersRaw: String,
        foregroundServiceEnabled: Boolean
    ) {
        val cleanedSenders = allowedSendersRaw.ifBlank { SenderFilter.DEFAULT_ALLOWED_SENDERS_RAW }
        secretStore.saveSecret(webhookSecret)
        secretState.value = webhookSecret
        dataStore.edit { prefs ->
            prefs[KEY_WEBHOOK_URL] = webhookUrl.trim()
            prefs[KEY_ALLOWED_SENDERS] = cleanedSenders
            prefs[KEY_FOREGROUND_SERVICE] = foregroundServiceEnabled
        }
    }

    suspend fun setForegroundServiceEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_FOREGROUND_SERVICE] = enabled
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_ONBOARDING_COMPLETED] = completed
        }
    }

    companion object {
        private val KEY_WEBHOOK_URL = stringPreferencesKey("webhook_url")
        private val KEY_ALLOWED_SENDERS = stringPreferencesKey("allowed_senders")
        private val KEY_FOREGROUND_SERVICE = booleanPreferencesKey("foreground_service_enabled")
        private val KEY_ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
    }
}
