package com.payforwarder.app.domain

import android.content.Intent
import android.provider.Telephony
import android.telephony.SubscriptionManager

object SmsMessageParser {

    fun joinMultipartParts(
        parts: List<ParsedSmsPart>,
        simSlot: Int?,
        fallbackTimestampMillis: Long = System.currentTimeMillis()
    ): List<JoinedSms> {
        if (parts.isEmpty()) return emptyList()

        val grouped = linkedMapOf<String, MutableList<ParsedSmsPart>>()
        for (part in parts) {
            val sender = part.sender.trim()
            if (sender.isEmpty()) continue
            grouped.getOrPut(sender) { mutableListOf() }.add(part)
        }

        return grouped.map { (sender, senderParts) ->
            val joinedText = senderParts.joinToString(separator = "") { it.body }
            val timestamp = senderParts
                .firstOrNull { it.timestampMillis > 0L }
                ?.timestampMillis
                ?: fallbackTimestampMillis
            JoinedSms(
                sender = sender,
                text = joinedText,
                timestampMillis = timestamp,
                simSlot = simSlot
            )
        }.filter { it.text.isNotEmpty() }
    }

    fun fromIntent(
        intent: Intent,
        slotResolver: (Int) -> Int? = { SubscriptionManager.INVALID_SIM_SLOT_INDEX },
        fallbackTimestampMillis: Long = System.currentTimeMillis()
    ): List<JoinedSms> {
        val rawMessages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return emptyList()
        if (rawMessages.isEmpty()) return emptyList()

        val simSlot = extractSimSlot(intent, slotResolver)
        val parts = rawMessages.mapNotNull { sms ->
            val sender = sms.displayOriginatingAddress ?: sms.originatingAddress ?: return@mapNotNull null
            val body = sms.displayMessageBody ?: sms.messageBody ?: ""
            ParsedSmsPart(
                sender = sender,
                body = body,
                timestampMillis = sms.timestampMillis
            )
        }
        return joinMultipartParts(parts, simSlot, fallbackTimestampMillis)
    }

    fun extractSimSlot(
        intent: Intent,
        slotResolver: (Int) -> Int? = { null }
    ): Int? {
        val directKeys = listOf(
            "android.telephony.extra.SLOT_INDEX",
            "slot",
            "simSlot",
            "slot_id",
            "simId"
        )
        for (key in directKeys) {
            if (intent.hasExtra(key)) {
                val value = intent.getIntExtra(key, -1)
                if (value >= 0) return value + 1
            }
        }

        val subKeys = listOf(
            SubscriptionManager.EXTRA_SUBSCRIPTION_INDEX,
            "subscription",
            "sub_id"
        )
        for (key in subKeys) {
            if (intent.hasExtra(key)) {
                val subId = intent.getIntExtra(key, SubscriptionManager.INVALID_SUBSCRIPTION_ID)
                if (subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID && subId >= 0) {
                    val resolvedIndex = slotResolver(subId)
                    if (resolvedIndex != null && resolvedIndex >= 0 && resolvedIndex != SubscriptionManager.INVALID_SIM_SLOT_INDEX) {
                        return resolvedIndex + 1
                    }
                }
            }
        }
        return null
    }
}
