package com.payforwarder.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme - Soft Atmospheric Frost & Obsidian Ink
val LightBackground = Color(0xFFF4F6FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF1F8)
val LightOutline = Color(0xFFE2E6F0)
val LightInk = Color(0xFF111318)
val LightMutedInk = Color(0xFF5D6475)

val LightPeachGlow = Color(0xFFFFE2CF)
val LightPeachSurface = Color(0xFFFFF1E8)
val LightPeriwinkleGlow = Color(0xFFDCE3FF)
val LightPeriwinkleSurface = Color(0xFFEEF2FF)

// Dark Theme - Deep Obsidian & Warm Champagne
val DarkBackground = Color(0xFF0C0E14)
val DarkSurface = Color(0xFF161922)
val DarkSurfaceVariant = Color(0xFF1F2330)
val DarkOutline = Color(0xFF282D3D)
val DarkInk = Color(0xFFF5F7FA)
val DarkMutedInk = Color(0xFF9CA3B5)

val DarkPeachGlow = Color(0xFF2B1E1B)
val DarkPeachSurface = Color(0xFF261C19)
val DarkPeriwinkleGlow = Color(0xFF161B2E)
val DarkPeriwinkleSurface = Color(0xFF1A2033)

// Brand & Semantic Status Accents
val PrimaryObsidian = Color(0xFF111318)
val PrimaryPeriwinkle = Color(0xFF5B6CFA)
val PrimaryPeach = Color(0xFFFFB58A)

val StatusEmerald = Color(0xFF0E9F6E)
val StatusEmeraldBgLight = Color(0xFFE8FBF3)
val StatusEmeraldBgDark = Color(0xFF102A22)

val StatusAmber = Color(0xFFD97706)
val StatusAmberBgLight = Color(0xFFFFF6E5)
val StatusAmberBgDark = Color(0xFF2B2110)

val StatusCrimson = Color(0xFFDC2626)
val StatusCrimsonBgLight = Color(0xFFFEF0F0)
val StatusCrimsonBgDark = Color(0xFF2E1416)
