package com.payforwarder.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.payforwarder.app.PayForwarderApp
import com.payforwarder.app.notifications.NotificationHelper
import com.payforwarder.app.worker.WorkScheduler

class PaymentWatcherService : Service() {

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        registerConnectivityTrigger()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val app = applicationContext as? PayForwarderApp
        val notification = app?.container?.notificationHelper?.buildWatcherNotification()
            ?: NotificationHelper(this).buildWatcherNotification()

        val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }

        ServiceCompat.startForeground(
            this,
            NotificationHelper.WATCHER_NOTIFICATION_ID,
            notification,
            serviceType
        )

        return START_STICKY
    }

    override fun onDestroy() {
        unregisterConnectivityTrigger()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerConnectivityTrigger() {
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                WorkScheduler.enqueuePendingForwarding(applicationContext)
            }
        }
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching {
            manager.registerNetworkCallback(request, callback)
            connectivityManager = manager
            networkCallback = callback
        }
    }

    private fun unregisterConnectivityTrigger() {
        val manager = connectivityManager ?: return
        val callback = networkCallback ?: return
        runCatching { manager.unregisterNetworkCallback(callback) }
        connectivityManager = null
        networkCallback = null
    }

    companion object {
        private const val ACTION_STOP = "com.payforwarder.app.action.STOP_WATCHER"

        fun startSafely(context: Context) {
            val intent = Intent(context, PaymentWatcherService::class.java)
            runCatching {
                ContextCompat.startForegroundService(context, intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, PaymentWatcherService::class.java)
            context.stopService(intent)
        }

        fun sync(context: Context, enabled: Boolean) {
            if (enabled) {
                startSafely(context)
            } else {
                stop(context)
            }
        }
    }
}
