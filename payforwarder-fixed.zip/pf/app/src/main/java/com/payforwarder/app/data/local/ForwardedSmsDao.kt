package com.payforwarder.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.payforwarder.app.domain.SmsStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface ForwardedSmsDao {

    @Query("SELECT * FROM forwarded_sms ORDER BY receivedAt DESC, id DESC LIMIT :limit")
    fun observeRecent(limit: Int = 100): Flow<List<ForwardedSmsEntity>>

    @Query("SELECT COUNT(*) FROM forwarded_sms WHERE status = 'SENT' AND sentAt >= :startOfDayMillis")
    fun observeSentCountSince(startOfDayMillis: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM forwarded_sms WHERE status = 'PENDING'")
    fun observePendingCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM forwarded_sms WHERE status IN ('FAILED', 'FAILED_AUTH')")
    fun observeFailedCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(entity: ForwardedSmsEntity): Long

    @Query("SELECT * FROM forwarded_sms WHERE status = 'PENDING' ORDER BY receivedAt ASC, id ASC")
    suspend fun getPendingItems(): List<ForwardedSmsEntity>

    @Query("SELECT * FROM forwarded_sms WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ForwardedSmsEntity?

    @Query(
        """
        UPDATE forwarded_sms
        SET status = :status,
            attemptCount = :attemptCount,
            lastAttemptAt = :lastAttemptAt,
            sentAt = :sentAt,
            lastHttpCode = :lastHttpCode,
            lastError = :lastError
        WHERE id = :id
        """
    )
    suspend fun updateDeliveryState(
        id: Long,
        status: SmsStatus,
        attemptCount: Int,
        lastAttemptAt: Long?,
        sentAt: Long?,
        lastHttpCode: Int?,
        lastError: String?
    )

    @Query("UPDATE forwarded_sms SET status = 'PENDING', lastError = NULL WHERE id = :id")
    suspend fun resetForRetry(id: Long)

    @Query("DELETE FROM forwarded_sms")
    suspend fun clearAll()
}
