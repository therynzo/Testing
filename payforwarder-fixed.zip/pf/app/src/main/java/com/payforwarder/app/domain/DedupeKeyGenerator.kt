package com.payforwarder.app.domain

import java.security.MessageDigest

object DedupeKeyGenerator {
    fun generate(sender: String, text: String, timestampMillis: Long): String {
        val normalized = "${sender.trim()}\u0000$text\u0000$timestampMillis"
        val digest = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray(Charsets.UTF_8))
        return digest.joinToString(separator = "") { byte -> "%02x".format(byte) }
    }
}
