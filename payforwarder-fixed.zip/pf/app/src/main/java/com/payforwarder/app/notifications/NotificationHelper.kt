package com.payforwarder.app.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.payforwarder.app.MainActivity
import com.payforwarder.app.R

class NotificationHelper(private val context: Context) {

    fun ensureChannels() {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val watcherChannel = NotificationChannel(
            CHANNEL_WATCHER_ID,
            context.getString(R.string.notification_channel_watcher_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = context.getString(R.string.notification_channel_watcher_desc)
            setShowBadge(false)
        }

        val alertChannel = NotificationChannel(
            CHANNEL_ALERTS_ID,
            context.getString(R.string.notification_channel_alerts_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.notification_channel_alerts_desc)
        }

        manager.createNotificationChannel(watcherChannel)
        manager.createNotificationChannel(alertChannel)
    }

    fun buildWatcherNotification(): Notification {
        ensureChannels()
        return NotificationCompat.Builder(context, CHANNEL_WATCHER_ID)
            .setSmallIcon(R.drawable.ic_stat_payforwarder)
            .setContentTitle(context.getString(R.string.watcher_notification_title))
            .setContentText(context.getString(R.string.watcher_notification_text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(mainActivityPendingIntent())
            .build()
    }

    fun showAuthErrorNotification() {
        ensureChannels()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS_ID)
            .setSmallIcon(R.drawable.ic_stat_payforwarder)
            .setContentTitle(context.getString(R.string.auth_error_notification_title))
            .setContentText(context.getString(R.string.auth_error_notification_text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(mainActivityPendingIntent(openSettings = true))
            .build()

        NotificationManagerCompat.from(context).notify(AUTH_ERROR_NOTIFICATION_ID, notification)
    }

    private fun mainActivityPendingIntent(openSettings: Boolean = false): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (openSettings) {
                putExtra(EXTRA_OPEN_SETTINGS, true)
            }
        }
        return PendingIntent.getActivity(
            context,
            if (openSettings) 2002 else 2001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object {
        const val CHANNEL_WATCHER_ID = "payforwarder_watcher"
        const val CHANNEL_ALERTS_ID = "payforwarder_alerts"
        const val WATCHER_NOTIFICATION_ID = 1001
        const val AUTH_ERROR_NOTIFICATION_ID = 1002
        const val EXTRA_OPEN_SETTINGS = "extra_open_settings"
    }
}
