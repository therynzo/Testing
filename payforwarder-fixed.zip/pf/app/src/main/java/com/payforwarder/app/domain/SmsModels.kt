package com.payforwarder.app.domain

enum class SmsStatus {
    PENDING,
    SENT,
    FAILED,
    FAILED_AUTH
}

data class ParsedSmsPart(
    val sender: String,
    val body: String,
    val timestampMillis: Long
)

data class JoinedSms(
    val sender: String,
    val text: String,
    val timestampMillis: Long,
    val simSlot: Int?
)
