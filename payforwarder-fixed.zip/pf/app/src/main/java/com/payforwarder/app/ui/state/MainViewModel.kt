package com.payforwarder.app.ui.state

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.payforwarder.app.PayForwarderApp
import com.payforwarder.app.data.local.ForwardedSmsEntity
import com.payforwarder.app.data.network.TestWebhookResponse
import com.payforwarder.app.data.preferences.AppSettings
import com.payforwarder.app.service.PaymentWatcherService
import com.payforwarder.app.worker.WorkScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SystemHealthState(
    val hasSmsPermission: Boolean = false,
    val hasNotificationPermission: Boolean = true,
    val isBatteryOptimizationExempt: Boolean = false
)

data class MainUiState(
    val settings: AppSettings = AppSettings(),
    val health: SystemHealthState = SystemHealthState(),
    val recentSms: List<ForwardedSmsEntity> = emptyList(),
    val sentToday: Int = 0,
    val pendingCount: Int = 0,
    val failedCount: Int = 0,
    val selectedSms: ForwardedSmsEntity? = null,
    val isSendingTest: Boolean = false,
    val testResponse: TestWebhookResponse? = null,
    val statusBannerMessage: String? = null
) {
    val isFullyActive: Boolean
        get() = health.hasSmsPermission &&
            health.isBatteryOptimizationExempt &&
            settings.isWebhookConfigured

    val missingRequirements: List<String>
        get() = buildList {
            if (!health.hasSmsPermission) add("SMS permission (RECEIVE_SMS / READ_SMS)")
            if (!health.hasNotificationPermission) add("Notification permission (POST_NOTIFICATIONS)")
            if (!health.isBatteryOptimizationExempt) add("Battery optimization exemption")
            if (!settings.isWebhookConfigured) add("Webhook URL in Settings")
        }
}

class MainViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val app = application as PayForwarderApp
    private val repository = app.container.repository
    private val settingsRepository = app.container.settingsRepository

    private val healthState = MutableStateFlow(readSystemHealth())
    private val selectedSmsState = MutableStateFlow<ForwardedSmsEntity?>(null)
    private val isSendingTestState = MutableStateFlow(false)
    private val testResponseState = MutableStateFlow<TestWebhookResponse?>(null)
    private val bannerMessageState = MutableStateFlow<String?>(null)

    private data class CountsBundle(
        val sentToday: Int,
        val pending: Int,
        val failed: Int
    )

    private val countsFlow = combine(
        repository.observeSentToday(),
        repository.observePendingCount(),
        repository.observeFailedCount()
    ) { sent, pending, failed ->
        CountsBundle(sent, pending, failed)
    }

    private data class TransientUiBundle(
        val selectedSms: ForwardedSmsEntity?,
        val isSendingTest: Boolean,
        val testResponse: TestWebhookResponse?,
        val bannerMessage: String?
    )

    private val transientFlow = combine(
        selectedSmsState,
        isSendingTestState,
        testResponseState,
        bannerMessageState
    ) { selected, sending, testResp, banner ->
        TransientUiBundle(selected, sending, testResp, banner)
    }

    val uiState: StateFlow<MainUiState> = combine(
        settingsRepository.settingsFlow,
        healthState,
        repository.observeRecentSms(100),
        countsFlow,
        transientFlow
    ) { settings, health, recent, counts, transient ->
        MainUiState(
            settings = settings,
            health = health,
            recentSms = recent,
            sentToday = counts.sentToday,
            pendingCount = counts.pending,
            failedCount = counts.failed,
            selectedSms = transient.selectedSms,
            isSendingTest = transient.isSendingTest,
            testResponse = transient.testResponse,
            statusBannerMessage = transient.bannerMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = MainUiState(health = readSystemHealth())
    )

    fun refreshSystemHealth() {
        val currentHealth = readSystemHealth()
        healthState.value = currentHealth
        viewModelScope.launch {
            val settings = settingsRepository.getCurrentSettings()
            if (currentHealth.hasSmsPermission) {
                PaymentWatcherService.sync(app, settings.foregroundServiceEnabled)
            }
        }
    }

    fun markOnboardingComplete() {
        viewModelScope.launch {
            settingsRepository.setOnboardingCompleted(true)
            val settings = settingsRepository.getCurrentSettings()
            if (readSystemHealth().hasSmsPermission && settings.foregroundServiceEnabled) {
                PaymentWatcherService.startSafely(app)
            }
        }
    }

    fun selectSms(item: ForwardedSmsEntity?) {
        selectedSmsState.value = item
    }

    fun retrySms(id: Long) {
        viewModelScope.launch {
            repository.retryItem(id)
            WorkScheduler.enqueuePendingForwarding(app)
            selectedSmsState.value = null
            bannerMessageState.value = "Queued for immediate retry"
        }
    }

    fun saveSettings(
        webhookUrl: String,
        webhookSecret: String,
        allowedSendersRaw: String,
        foregroundServiceEnabled: Boolean
    ) {
        viewModelScope.launch {
            settingsRepository.updateSettings(
                webhookUrl = webhookUrl,
                webhookSecret = webhookSecret,
                allowedSendersRaw = allowedSendersRaw,
                foregroundServiceEnabled = foregroundServiceEnabled
            )
            if (readSystemHealth().hasSmsPermission) {
                PaymentWatcherService.sync(app, foregroundServiceEnabled)
            }
            WorkScheduler.enqueuePendingForwarding(app)
            bannerMessageState.value = "Settings saved"
        }
    }

    fun toggleForegroundService(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setForegroundServiceEnabled(enabled)
            if (readSystemHealth().hasSmsPermission || !enabled) {
                PaymentWatcherService.sync(app, enabled)
            }
        }
    }

    fun sendTestWebhook(webhookUrl: String, webhookSecret: String) {
        viewModelScope.launch {
            isSendingTestState.value = true
            testResponseState.value = null
            val response = repository.sendTestWebhook(webhookUrl, webhookSecret)
            testResponseState.value = response
            isSendingTestState.value = false
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            selectedSmsState.value = null
            bannerMessageState.value = "History cleared"
        }
    }

    fun clearBannerMessage() {
        bannerMessageState.value = null
    }

    private fun readSystemHealth(): SystemHealthState {
        val receiveGranted = ContextCompat.checkSelfPermission(
            app,
            Manifest.permission.RECEIVE_SMS
        ) == PackageManager.PERMISSION_GRANTED
        val readGranted = ContextCompat.checkSelfPermission(
            app,
            Manifest.permission.READ_SMS
        ) == PackageManager.PERMISSION_GRANTED
        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                app,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        val powerManager = app.getSystemService(PowerManager::class.java)
        val batteryExempt = powerManager?.isIgnoringBatteryOptimizations(app.packageName) ?: false

        return SystemHealthState(
            hasSmsPermission = receiveGranted && readGranted,
            hasNotificationPermission = notifGranted,
            isBatteryOptimizationExempt = batteryExempt
        )
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(application) as T
        }
    }
}
