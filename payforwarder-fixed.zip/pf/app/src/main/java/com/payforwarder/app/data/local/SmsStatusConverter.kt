package com.payforwarder.app.data.local

import androidx.room.TypeConverter
import com.payforwarder.app.domain.SmsStatus

class SmsStatusConverter {
    @TypeConverter
    fun fromStatus(status: SmsStatus): String = status.name

    @TypeConverter
    fun toStatus(value: String): SmsStatus {
        return runCatching { SmsStatus.valueOf(value) }.getOrDefault(SmsStatus.PENDING)
    }
}
