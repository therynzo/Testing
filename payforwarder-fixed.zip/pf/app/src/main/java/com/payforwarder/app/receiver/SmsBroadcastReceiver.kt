package com.payforwarder.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SubscriptionManager
import com.payforwarder.app.PayForwarderApp
import com.payforwarder.app.domain.SmsMessageParser
import com.payforwarder.app.worker.WorkScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SmsBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val app = context.applicationContext as? PayForwarderApp ?: return
        val pendingResult = goAsync()

        val joinedMessages = SmsMessageParser.fromIntent(
            intent = intent,
            slotResolver = { subId ->
                runCatching {
                    val slot = SubscriptionManager.getSlotIndex(subId)
                    if (slot == SubscriptionManager.INVALID_SIM_SLOT_INDEX) null else slot
                }.getOrNull()
            }
        )

        if (joinedMessages.isEmpty()) {
            pendingResult.finish()
            return
        }

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val inserted = app.container.repository.ingestIncomingSms(joinedMessages)
                if (inserted > 0) {
                    WorkScheduler.enqueuePendingForwarding(app)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
