package com.payforwarder.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.payforwarder.app.R
import com.payforwarder.app.data.network.TestWebhookResponse
import com.payforwarder.app.ui.state.MainUiState
import com.payforwarder.app.ui.theme.JetBrainsMono
import com.payforwarder.app.ui.theme.LocalPayForwarderColors

@Composable
fun SettingsScreen(
    uiState: MainUiState,
    contentPadding: PaddingValues,
    onSaveSettings: (url: String, secret: String, allowedSenders: String, fgEnabled: Boolean) -> Unit,
    onToggleForegroundService: (Boolean) -> Unit,
    onSendTest: (url: String, secret: String) -> Unit,
    onRequestBatteryExemption: () -> Unit,
    onClearHistory: () -> Unit
) {
    var webhookUrl by rememberSaveable { mutableStateOf(uiState.settings.webhookUrl) }
    var webhookSecret by rememberSaveable { mutableStateOf(uiState.settings.webhookSecret) }
    var allowedSenders by rememberSaveable { mutableStateOf(uiState.settings.allowedSendersRaw) }
    var fgEnabled by rememberSaveable { mutableStateOf(uiState.settings.foregroundServiceEnabled) }
    var secretVisible by rememberSaveable { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }

    LaunchedEffect(
        uiState.settings.webhookUrl,
        uiState.settings.webhookSecret,
        uiState.settings.allowedSendersRaw,
        uiState.settings.foregroundServiceEnabled
    ) {
        if (webhookUrl.isEmpty() && uiState.settings.webhookUrl.isNotEmpty()) {
            webhookUrl = uiState.settings.webhookUrl
        }
        if (webhookSecret.isEmpty() && uiState.settings.webhookSecret.isNotEmpty()) {
            webhookSecret = uiState.settings.webhookSecret
        }
        allowedSenders = uiState.settings.allowedSendersRaw
        fgEnabled = uiState.settings.foregroundServiceEnabled
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear SMS History?") },
            text = { Text("This deletes all stored SMS logs from this device. Settings and webhook secret are kept.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                        onClearHistory()
                    },
                    modifier = Modifier.testTag("confirm_clear_history_button")
                ) {
                    Text("Clear", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Box(
        contentAlignment = Alignment.TopCenter,
        modifier = Modifier
            .fillMaxSize()
            .padding(top = contentPadding.calculateTopPadding())
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 18.dp,
                    end = 18.dp,
                    top = 12.dp,
                    bottom = contentPadding.calculateBottomPadding() + 96.dp
                ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = stringResource(R.string.nav_settings),
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onBackground
            )

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Webhook Endpoint",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = webhookUrl,
                        onValueChange = { webhookUrl = it },
                        label = { Text(stringResource(R.string.webhook_url_label)) },
                        placeholder = { Text(stringResource(R.string.webhook_url_placeholder)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("webhook_url_input")
                    )

                    OutlinedTextField(
                        value = webhookSecret,
                        onValueChange = { webhookSecret = it },
                        label = { Text(stringResource(R.string.webhook_secret_label)) },
                        singleLine = true,
                        visualTransformation = if (secretVisible) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(
                                onClick = { secretVisible = !secretVisible },
                                modifier = Modifier.testTag("toggle_secret_visibility_button")
                            ) {
                                Icon(
                                    imageVector = if (secretVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (secretVisible) "Hide secret" else "Show secret"
                                )
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("webhook_secret_input")
                    )

                    OutlinedTextField(
                        value = allowedSenders,
                        onValueChange = { allowedSenders = it },
                        label = { Text(stringResource(R.string.allowed_senders_label)) },
                        supportingText = { Text(stringResource(R.string.allowed_senders_hint)) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("allowed_senders_input")
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = { onSendTest(webhookUrl, webhookSecret) },
                            enabled = !uiState.isSendingTest,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("send_test_button")
                        ) {
                            if (uiState.isSendingTest) {
                                CircularProgressIndicator(
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Send,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.send_test_button))
                        }

                        Button(
                            onClick = {
                                onSaveSettings(webhookUrl, webhookSecret, allowedSenders, fgEnabled)
                            },
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("save_settings_button")
                        ) {
                            Text(stringResource(R.string.save_settings_button))
                        }
                    }

                    uiState.testResponse?.let { result ->
                        TestResultCard(result = result)
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Background Reliability",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.foreground_service_label),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.foreground_service_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Switch(
                            checked = fgEnabled,
                            onCheckedChange = { checked ->
                                fgEnabled = checked
                                onToggleForegroundService(checked)
                            },
                            modifier = Modifier.testTag("foreground_service_switch")
                        )
                    }

                    val extended = LocalPayForwarderColors.current
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Battery Optimization",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (uiState.health.isBatteryOptimizationExempt) {
                                    "Exempted (unrestricted background delivery)"
                                } else {
                                    "Restricted — tap Exempt to prevent Android sleep delays"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (uiState.health.isBatteryOptimizationExempt) {
                                    extended.emerald
                                } else {
                                    extended.amber
                                }
                            )
                        }
                        if (!uiState.health.isBatteryOptimizationExempt) {
                            Spacer(modifier = Modifier.width(10.dp))
                            OutlinedButton(
                                onClick = onRequestBatteryExemption,
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("settings_battery_exempt_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.BatteryChargingFull,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Exempt")
                            }
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(18.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Local SMS History",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Clear all stored forwarded & pending SMS records",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    OutlinedButton(
                        onClick = { showClearDialog = true },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("clear_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = null,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.clear_history_button))
                    }
                }
            }
        }
    }
}

@Composable
private fun TestResultCard(result: TestWebhookResponse) {
    val extended = LocalPayForwarderColors.current
    val fg = if (result.isSuccess) extended.emerald else extended.crimson
    val bg = if (result.isSuccess) extended.emeraldContainer else extended.crimsonContainer

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = bg,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("test_webhook_result")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = if (result.statusCode != null) {
                    "HTTP ${result.statusCode} · ${if (result.isSuccess) "Connection Working" else "Error"}"
                } else {
                    "Connection Failed"
                },
                style = MaterialTheme.typography.labelLarge,
                color = fg
            )
            if (result.errorMessage != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = result.errorMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = fg
                )
            }
            if (result.body.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = result.body,
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMono),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
