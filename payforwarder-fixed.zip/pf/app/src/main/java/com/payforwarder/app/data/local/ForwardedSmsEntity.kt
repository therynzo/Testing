package com.payforwarder.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.payforwarder.app.domain.SmsStatus

@Entity(
    tableName = "forwarded_sms",
    indices = [
        Index(value = ["dedupeKey"], unique = true),
        Index(value = ["status"]),
        Index(value = ["createdAt"])
    ]
)
data class ForwardedSmsEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String,
    val text: String,
    val receivedAt: Long,
    val createdAt: Long,
    val simSlot: Int? = null,
    val status: SmsStatus = SmsStatus.PENDING,
    val attemptCount: Int = 0,
    val lastAttemptAt: Long? = null,
    val sentAt: Long? = null,
    val lastHttpCode: Int? = null,
    val lastError: String? = null,
    val dedupeKey: String
)
