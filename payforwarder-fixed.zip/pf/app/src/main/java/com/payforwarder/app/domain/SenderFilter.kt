package com.payforwarder.app.domain

object SenderFilter {
    val DEFAULT_ALLOWED_SENDERS: List<String> = listOf("bkash", "nagad")
    const val DEFAULT_ALLOWED_SENDERS_RAW: String = "bkash, nagad"

    fun parseAllowedSenders(raw: String): List<String> {
        return raw.split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    fun isSenderAllowed(sender: String, allowedSenders: List<String>): Boolean {
        val trimmedSender = sender.trim()
        if (trimmedSender.isEmpty()) return false
        return allowedSenders
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .any { token -> trimmedSender.contains(token, ignoreCase = true) }
    }
}
