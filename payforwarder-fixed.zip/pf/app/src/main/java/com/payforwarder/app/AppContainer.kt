package com.payforwarder.app

import android.content.Context
import com.payforwarder.app.data.local.PayForwarderDatabase
import com.payforwarder.app.data.network.WebhookClient
import com.payforwarder.app.data.preferences.KeystoreSecretStore
import com.payforwarder.app.data.preferences.SettingsRepository
import com.payforwarder.app.data.repository.SmsForwarderRepository
import com.payforwarder.app.notifications.NotificationHelper

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: PayForwarderDatabase by lazy {
        PayForwarderDatabase.create(appContext)
    }

    val secretStore: KeystoreSecretStore by lazy {
        KeystoreSecretStore(appContext)
    }

    val settingsRepository: SettingsRepository by lazy {
        SettingsRepository(appContext, secretStore)
    }

    val webhookClient: WebhookClient by lazy {
        WebhookClient()
    }

    val notificationHelper: NotificationHelper by lazy {
        NotificationHelper(appContext)
    }

    val repository: SmsForwarderRepository by lazy {
        SmsForwarderRepository(
            dao = database.forwardedSmsDao(),
            settingsRepository = settingsRepository,
            webhookClient = webhookClient
        )
    }
}
