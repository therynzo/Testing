package com.payforwarder.app.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.payforwarder.app.PayForwarderApp
import com.payforwarder.app.data.repository.QueueProcessingOutcome

class PendingSmsWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? PayForwarderApp ?: return Result.failure()
        val container = app.container

        val outcome = container.repository.processPendingQueue(
            onAuthFailure = { container.notificationHelper.showAuthErrorNotification() }
        )

        return mapOutcomeToResult(outcome)
    }

    companion object {
        fun mapOutcomeToResult(outcome: QueueProcessingOutcome): Result {
            return when (outcome) {
                QueueProcessingOutcome.ALL_DONE -> Result.success()
                QueueProcessingOutcome.RETRY_PENDING -> Result.retry()
                QueueProcessingOutcome.AUTH_FAILED -> Result.failure()
                QueueProcessingOutcome.NEEDS_CONFIGURATION -> Result.failure()
            }
        }
    }
}
