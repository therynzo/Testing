package com.payforwarder.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [ForwardedSmsEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(SmsStatusConverter::class)
abstract class PayForwarderDatabase : RoomDatabase() {
    abstract fun forwardedSmsDao(): ForwardedSmsDao

    companion object {
        private const val DB_NAME = "payforwarder.db"

        fun create(context: Context): PayForwarderDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                PayForwarderDatabase::class.java,
                DB_NAME
            ).build()
        }

        fun createInMemory(context: Context): PayForwarderDatabase {
            return Room.inMemoryDatabaseBuilder(
                context.applicationContext,
                PayForwarderDatabase::class.java
            ).allowMainThreadQueries().build()
        }
    }
}
