package com.payforwarder.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.payforwarder.app.PayForwarderApp
import com.payforwarder.app.service.PaymentWatcherService
import com.payforwarder.app.worker.WorkScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }

        val app = context.applicationContext as? PayForwarderApp ?: return
        val pendingResult = goAsync()

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                WorkScheduler.enqueuePendingForwarding(app)
                val settings = app.container.settingsRepository.getCurrentSettings()
                if (settings.foregroundServiceEnabled) {
                    PaymentWatcherService.startSafely(app)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
