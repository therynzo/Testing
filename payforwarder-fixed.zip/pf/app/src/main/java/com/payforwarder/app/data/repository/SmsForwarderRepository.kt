package com.payforwarder.app.data.repository

import com.payforwarder.app.data.local.ForwardedSmsDao
import com.payforwarder.app.data.local.ForwardedSmsEntity
import com.payforwarder.app.data.network.TestWebhookResponse
import com.payforwarder.app.data.network.WebhookClient
import com.payforwarder.app.data.network.WebhookResult
import com.payforwarder.app.data.preferences.SettingsRepository
import com.payforwarder.app.domain.DedupeKeyGenerator
import com.payforwarder.app.domain.JoinedSms
import com.payforwarder.app.domain.SenderFilter
import com.payforwarder.app.domain.SmsStatus
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.ZoneId

enum class QueueProcessingOutcome {
    ALL_DONE,
    RETRY_PENDING,
    AUTH_FAILED,
    NEEDS_CONFIGURATION
}

class SmsForwarderRepository(
    private val dao: ForwardedSmsDao,
    private val settingsRepository: SettingsRepository,
    private val webhookClient: WebhookClient
) {
    fun observeRecentSms(limit: Int = 100): Flow<List<ForwardedSmsEntity>> = dao.observeRecent(limit)

    fun observeSentToday(): Flow<Int> {
        val startOfDay = LocalDate.now()
            .atStartOfDay(ZoneId.systemDefault())
            .toInstant()
            .toEpochMilli()
        return dao.observeSentCountSince(startOfDay)
    }

    fun observePendingCount(): Flow<Int> = dao.observePendingCount()

    fun observeFailedCount(): Flow<Int> = dao.observeFailedCount()

    suspend fun ingestIncomingSms(
        messages: List<JoinedSms>,
        nowMillis: Long = System.currentTimeMillis()
    ): Int {
        if (messages.isEmpty()) return 0
        val settings = settingsRepository.getCurrentSettings()
        val allowedSenders = settings.allowedSenders

        var insertedCount = 0
        for (sms in messages) {
            if (!SenderFilter.isSenderAllowed(sms.sender, allowedSenders)) {
                continue
            }
            val dedupeKey = DedupeKeyGenerator.generate(
                sender = sms.sender,
                text = sms.text,
                timestampMillis = sms.timestampMillis
            )
            val entity = ForwardedSmsEntity(
                sender = sms.sender,
                text = sms.text,
                receivedAt = sms.timestampMillis,
                createdAt = nowMillis,
                simSlot = sms.simSlot,
                status = SmsStatus.PENDING,
                attemptCount = 0,
                dedupeKey = dedupeKey
            )
            val insertedId = dao.insertIgnore(entity)
            if (insertedId != -1L) {
                insertedCount++
            }
        }
        return insertedCount
    }

    suspend fun processPendingQueue(
        onAuthFailure: () -> Unit = {},
        nowProvider: () -> Long = { System.currentTimeMillis() }
    ): QueueProcessingOutcome {
        val pendingItems = dao.getPendingItems()
        if (pendingItems.isEmpty()) return QueueProcessingOutcome.ALL_DONE

        val settings = settingsRepository.getCurrentSettings()
        if (!settings.isWebhookConfigured) {
            return QueueProcessingOutcome.NEEDS_CONFIGURATION
        }

        var shouldRetry = false
        for (item in pendingItems) {
            val attemptTime = nowProvider()
            val nextAttempt = item.attemptCount + 1

            when (val result = webhookClient.sendSms(
                webhookUrl = settings.webhookUrl,
                secret = settings.webhookSecret,
                from = item.sender,
                text = item.text
            )) {
                is WebhookResult.Success -> {
                    dao.updateDeliveryState(
                        id = item.id,
                        status = SmsStatus.SENT,
                        attemptCount = nextAttempt,
                        lastAttemptAt = attemptTime,
                        sentAt = attemptTime,
                        lastHttpCode = result.code,
                        lastError = null
                    )
                }
                is WebhookResult.Unauthorized -> {
                    dao.updateDeliveryState(
                        id = item.id,
                        status = SmsStatus.FAILED_AUTH,
                        attemptCount = nextAttempt,
                        lastAttemptAt = attemptTime,
                        sentAt = null,
                        lastHttpCode = result.code,
                        lastError = "Wrong secret (HTTP 401)"
                    )
                    onAuthFailure()
                    return QueueProcessingOutcome.AUTH_FAILED
                }
                is WebhookResult.HttpFailure -> {
                    if (result.isRetryable) {
                        dao.updateDeliveryState(
                            id = item.id,
                            status = SmsStatus.PENDING,
                            attemptCount = nextAttempt,
                            lastAttemptAt = attemptTime,
                            sentAt = null,
                            lastHttpCode = result.code,
                            lastError = "HTTP ${result.code}: ${result.body.take(160)}"
                        )
                        shouldRetry = true
                    } else {
                        dao.updateDeliveryState(
                            id = item.id,
                            status = SmsStatus.FAILED,
                            attemptCount = nextAttempt,
                            lastAttemptAt = attemptTime,
                            sentAt = null,
                            lastHttpCode = result.code,
                            lastError = "HTTP ${result.code}: ${result.body.take(160)}"
                        )
                    }
                }
                is WebhookResult.NetworkFailure -> {
                    dao.updateDeliveryState(
                        id = item.id,
                        status = SmsStatus.PENDING,
                        attemptCount = nextAttempt,
                        lastAttemptAt = attemptTime,
                        sentAt = null,
                        lastHttpCode = null,
                        lastError = result.message.take(160)
                    )
                    shouldRetry = true
                }
                is WebhookResult.InvalidConfig -> {
                    dao.updateDeliveryState(
                        id = item.id,
                        status = SmsStatus.FAILED,
                        attemptCount = nextAttempt,
                        lastAttemptAt = attemptTime,
                        sentAt = null,
                        lastHttpCode = null,
                        lastError = result.reason
                    )
                }
            }
        }

        return if (shouldRetry) {
            QueueProcessingOutcome.RETRY_PENDING
        } else {
            QueueProcessingOutcome.ALL_DONE
        }
    }

    suspend fun retryItem(id: Long) {
        dao.resetForRetry(id)
    }

    suspend fun clearHistory() {
        dao.clearAll()
    }

    suspend fun sendTestWebhook(url: String, secret: String): TestWebhookResponse {
        return webhookClient.sendTest(url, secret)
    }
}
