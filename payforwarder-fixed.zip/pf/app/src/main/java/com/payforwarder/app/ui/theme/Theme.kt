package com.payforwarder.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Immutable
data class PayForwarderColors(
    val peachGlow: Color,
    val peachSurface: Color,
    val periwinkleGlow: Color,
    val periwinkleSurface: Color,
    val emerald: Color,
    val emeraldContainer: Color,
    val amber: Color,
    val amberContainer: Color,
    val crimson: Color,
    val crimsonContainer: Color,
    val navPillBackground: Color,
    val navPillSelected: Color,
    val navPillSelectedContent: Color,
    val navPillUnselectedContent: Color
)

private val LightExtendedColors = PayForwarderColors(
    peachGlow = LightPeachGlow,
    peachSurface = LightPeachSurface,
    periwinkleGlow = LightPeriwinkleGlow,
    periwinkleSurface = LightPeriwinkleSurface,
    emerald = StatusEmerald,
    emeraldContainer = StatusEmeraldBgLight,
    amber = StatusAmber,
    amberContainer = StatusAmberBgLight,
    crimson = StatusCrimson,
    crimsonContainer = StatusCrimsonBgLight,
    navPillBackground = PrimaryObsidian,
    navPillSelected = Color(0xFFFFFFFF),
    navPillSelectedContent = PrimaryObsidian,
    navPillUnselectedContent = Color(0xFFB3BAC8)
)

private val DarkExtendedColors = PayForwarderColors(
    peachGlow = DarkPeachGlow,
    peachSurface = DarkPeachSurface,
    periwinkleGlow = DarkPeriwinkleGlow,
    periwinkleSurface = DarkPeriwinkleSurface,
    emerald = Color(0xFF34D399),
    emeraldContainer = StatusEmeraldBgDark,
    amber = Color(0xFFFBBF24),
    amberContainer = StatusAmberBgDark,
    crimson = Color(0xFFF87171),
    crimsonContainer = StatusCrimsonBgDark,
    navPillBackground = Color(0xFF1D2230),
    navPillSelected = PrimaryPeach,
    navPillSelectedContent = PrimaryObsidian,
    navPillUnselectedContent = Color(0xFF9CA3B5)
)

val LocalPayForwarderColors = staticCompositionLocalOf { LightExtendedColors }

private val LightColorScheme = lightColorScheme(
    primary = PrimaryObsidian,
    onPrimary = Color.White,
    primaryContainer = LightPeriwinkleSurface,
    onPrimaryContainer = PrimaryObsidian,
    secondary = PrimaryPeriwinkle,
    onSecondary = Color.White,
    secondaryContainer = LightPeachSurface,
    onSecondaryContainer = PrimaryObsidian,
    tertiary = PrimaryPeach,
    background = LightBackground,
    onBackground = LightInk,
    surface = LightSurface,
    onSurface = LightInk,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightMutedInk,
    outline = LightOutline,
    error = StatusCrimson,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryPeach,
    onPrimary = PrimaryObsidian,
    primaryContainer = DarkPeriwinkleSurface,
    onPrimaryContainer = DarkInk,
    secondary = Color(0xFF8EA0FF),
    onSecondary = PrimaryObsidian,
    secondaryContainer = DarkPeachSurface,
    onSecondaryContainer = DarkInk,
    tertiary = PrimaryPeach,
    background = DarkBackground,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkMutedInk,
    outline = DarkOutline,
    error = Color(0xFFF87171),
    onError = PrimaryObsidian
)

private val PayForwarderShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun PayForwarderTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    val extended = if (darkTheme) DarkExtendedColors else LightExtendedColors

    CompositionLocalProvider(LocalPayForwarderColors provides extended) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = PayForwarderTypography,
            shapes = PayForwarderShapes,
            content = content
        )
    }
}
