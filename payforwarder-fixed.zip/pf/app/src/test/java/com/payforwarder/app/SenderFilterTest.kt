package com.payforwarder.app

import com.payforwarder.app.domain.SenderFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SenderFilterTest {

    @Test
    fun `default allowed senders match bKash and Nagad case-insensitively by substring`() {
        val defaults = SenderFilter.DEFAULT_ALLOWED_SENDERS

        assertTrue(SenderFilter.isSenderAllowed("bKash", defaults))
        assertTrue(SenderFilter.isSenderAllowed("BKASH", defaults))
        assertTrue(SenderFilter.isSenderAllowed("bKash-Alert", defaults))
        assertTrue(SenderFilter.isSenderAllowed("Nagad", defaults))
        assertTrue(SenderFilter.isSenderAllowed("NAGAD", defaults))
        assertTrue(SenderFilter.isSenderAllowed("MyNagadInfo", defaults))
    }

    @Test
    fun `non-matching senders are rejected`() {
        val defaults = SenderFilter.DEFAULT_ALLOWED_SENDERS

        assertFalse(SenderFilter.isSenderAllowed("Grameenphone", defaults))
        assertFalse(SenderFilter.isSenderAllowed("+8801711000000", defaults))
        assertFalse(SenderFilter.isSenderAllowed("Rocket", defaults))
        assertFalse(SenderFilter.isSenderAllowed("   ", defaults))
        assertFalse(SenderFilter.isSenderAllowed("", defaults))
    }

    @Test
    fun `parses comma-separated sender list cleanly`() {
        val parsed = SenderFilter.parseAllowedSenders(" bkash , , nagad,  upay , ")
        assertEquals(listOf("bkash", "nagad", "upay"), parsed)
        assertTrue(SenderFilter.isSenderAllowed("UpayWallet", parsed))
        assertFalse(SenderFilter.isSenderAllowed("DBBL", parsed))
    }
}
