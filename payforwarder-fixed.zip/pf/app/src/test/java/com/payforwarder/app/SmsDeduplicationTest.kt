package com.payforwarder.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.payforwarder.app.data.local.PayForwarderDatabase
import com.payforwarder.app.data.network.WebhookClient
import com.payforwarder.app.data.preferences.SecretStore
import com.payforwarder.app.data.preferences.SettingsRepository
import com.payforwarder.app.data.repository.SmsForwarderRepository
import com.payforwarder.app.domain.JoinedSms
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SmsDeduplicationTest {

    private lateinit var db: PayForwarderDatabase
    private lateinit var repository: SmsForwarderRepository

    private class InMemorySecretStore : SecretStore {
        private var secret: String = ""
        override fun getSecret(): String = secret
        override fun saveSecret(secret: String) {
            this.secret = secret
        }
        override fun clearSecret() {
            this.secret = ""
        }
    }

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = PayForwarderDatabase.createInMemory(context)
        val settingsRepo = SettingsRepository(context, InMemorySecretStore())
        repository = SmsForwarderRepository(
            dao = db.forwardedSmsDao(),
            settingsRepository = settingsRepo,
            webhookClient = WebhookClient()
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `ignores identical sender, text, and timestamp seen twice`() = runTest {
        val sms = JoinedSms(
            sender = "bKash",
            text = "Received Tk 500.00. TrxID ABC123XYZ",
            timestampMillis = 1_700_000_000_000L,
            simSlot = 1
        )

        val firstInsert = repository.ingestIncomingSms(listOf(sms))
        val secondInsert = repository.ingestIncomingSms(listOf(sms))

        assertEquals(1, firstInsert)
        assertEquals(0, secondInsert)

        val stored = repository.observeRecentSms(100).first()
        assertEquals(1, stored.size)
        assertEquals("bKash", stored[0].sender)
        assertEquals(1, stored[0].simSlot)
    }

    @Test
    fun `allows same text when timestamp differs and ignores non-matching senders`() = runTest {
        val sms1 = JoinedSms("Nagad", "Cash In Tk 1000 TrxID N1", 1_000L, simSlot = 1)
        val sms2 = JoinedSms("Nagad", "Cash In Tk 1000 TrxID N1", 2_000L, simSlot = 2)
        val spam = JoinedSms("PromoOffer", "Win big prizes today!", 3_000L, simSlot = 1)

        val inserted = repository.ingestIncomingSms(listOf(sms1, sms2, spam))
        assertEquals(2, inserted)

        val stored = repository.observeRecentSms(100).first()
        assertEquals(2, stored.size)
        assertEquals(2, stored[0].simSlot)
        assertEquals(1, stored[1].simSlot)
    }
}
