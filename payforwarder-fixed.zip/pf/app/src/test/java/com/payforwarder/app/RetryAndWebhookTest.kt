package com.payforwarder.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.work.ListenableWorker
import com.payforwarder.app.data.local.PayForwarderDatabase
import com.payforwarder.app.data.network.WebhookClient
import com.payforwarder.app.data.preferences.SecretStore
import com.payforwarder.app.data.preferences.SettingsRepository
import com.payforwarder.app.data.repository.QueueProcessingOutcome
import com.payforwarder.app.data.repository.SmsForwarderRepository
import com.payforwarder.app.domain.JoinedSms
import com.payforwarder.app.domain.SmsStatus
import com.payforwarder.app.worker.PendingSmsWorker
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class RetryAndWebhookTest {

    private lateinit var db: PayForwarderDatabase
    private lateinit var settingsRepo: SettingsRepository
    private var nextResponder: (Request) -> Response = { req ->
        Response.Builder()
            .request(req)
            .protocol(Protocol.HTTP_1_1)
            .code(200)
            .message("OK")
            .body("""{"ok":true,"status":"saved"}""".toResponseBody("application/json".toMediaType()))
            .build()
    }
    private var capturedHeaders: Map<String, String> = emptyMap()
    private var capturedBody: String = ""

    private class InMemorySecretStore : SecretStore {
        private var secret: String = ""
        override fun getSecret(): String = secret
        override fun saveSecret(secret: String) {
            this.secret = secret
        }
        override fun clearSecret() {
            this.secret = ""
        }
    }

    private lateinit var repository: SmsForwarderRepository

    @Before
    fun setUp() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = PayForwarderDatabase.createInMemory(context)
        settingsRepo = SettingsRepository(context, InMemorySecretStore())
        settingsRepo.updateSettings(
            webhookUrl = "http://127.0.0.1:25570/webhook/sms",
            webhookSecret = "super-secret-token",
            allowedSendersRaw = "bkash, nagad",
            foregroundServiceEnabled = true
        )

        val interceptor = Interceptor { chain ->
            val request = chain.request()
            capturedHeaders = mapOf(
                "Content-Type" to (request.header("Content-Type") ?: ""),
                "X-Webhook-Secret" to (request.header("X-Webhook-Secret") ?: "")
            )
            val buffer = Buffer()
            request.body?.writeTo(buffer)
            capturedBody = buffer.readUtf8()
            nextResponder(request)
        }

        val okHttp = OkHttpClient.Builder()
            .addInterceptor(interceptor)
            .build()

        repository = SmsForwarderRepository(
            dao = db.forwardedSmsDao(),
            settingsRepository = settingsRepo,
            webhookClient = WebhookClient(okHttp)
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `http 200 marks SMS SENT and sends exact JSON payload and secret header`() = runTest {
        repository.ingestIncomingSms(
            listOf(JoinedSms("bKash", "Tk 1200 received TrxID XYZ999", 10_000L, simSlot = 2))
        )

        val outcome = repository.processPendingQueue()

        assertEquals(QueueProcessingOutcome.ALL_DONE, outcome)
        assertEquals(ListenableWorker.Result.success(), PendingSmsWorker.mapOutcomeToResult(outcome))
        assertEquals("super-secret-token", capturedHeaders["X-Webhook-Secret"])
        assertTrue(capturedHeaders["Content-Type"]?.startsWith("application/json") == true)

        val json = JSONObject(capturedBody)
        assertEquals("bKash", json.getString("from"))
        assertEquals("Tk 1200 received TrxID XYZ999", json.getString("text"))
        assertEquals(2, json.length()) // SIM slot must NOT be in POST body

        val items = repository.observeRecentSms(10).first()
        assertEquals(1, items.size)
        assertEquals(SmsStatus.SENT, items[0].status)
        assertEquals(1, items[0].attemptCount)
        assertEquals(200, items[0].lastHttpCode)
        assertNull(items[0].lastError)
    }

    @Test
    fun `http 401 marks FAILED_AUTH, triggers callback, and does not retry endlessly`() = runTest {
        nextResponder = { req ->
            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(401)
                .message("Unauthorized")
                .body("""{"ok":false,"error":"unauthorized"}""".toResponseBody("application/json".toMediaType()))
                .build()
        }

        repository.ingestIncomingSms(
            listOf(JoinedSms("Nagad", "Cash In Tk 500 TrxID N123", 20_000L, simSlot = 1))
        )

        var authAlertCount = 0
        val outcome = repository.processPendingQueue(onAuthFailure = { authAlertCount++ })

        assertEquals(1, authAlertCount)
        assertEquals(QueueProcessingOutcome.AUTH_FAILED, outcome)
        assertEquals(ListenableWorker.Result.failure(), PendingSmsWorker.mapOutcomeToResult(outcome))

        val items = repository.observeRecentSms(10).first()
        assertEquals(SmsStatus.FAILED_AUTH, items[0].status)
        assertEquals(401, items[0].lastHttpCode)
        assertEquals(1, items[0].attemptCount)
    }

    @Test
    fun `network failure keeps item PENDING and maps to WorkManager retry, then succeeds when restored`() = runTest {
        nextResponder = { throw IOException("Connection refused") }

        repository.ingestIncomingSms(
            listOf(JoinedSms("bKash", "Received Tk 900 TrxID TX11", 30_000L, simSlot = 1))
        )

        val firstOutcome = repository.processPendingQueue()
        assertEquals(QueueProcessingOutcome.RETRY_PENDING, firstOutcome)
        assertEquals(ListenableWorker.Result.retry(), PendingSmsWorker.mapOutcomeToResult(firstOutcome))

        val afterFirst = repository.observeRecentSms(10).first()
        assertEquals(SmsStatus.PENDING, afterFirst[0].status)
        assertEquals(1, afterFirst[0].attemptCount)

        // Network returns -> HTTP 200
        nextResponder = { req ->
            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body("""{"ok":true,"status":"saved"}""".toResponseBody("application/json".toMediaType()))
                .build()
        }

        val secondOutcome = repository.processPendingQueue()
        assertEquals(QueueProcessingOutcome.ALL_DONE, secondOutcome)

        val afterSecond = repository.observeRecentSms(10).first()
        assertEquals(SmsStatus.SENT, afterSecond[0].status)
        assertEquals(2, afterSecond[0].attemptCount)
    }

    @Test
    fun `manual retry resets FAILED_AUTH item back to PENDING and delivers on fixed secret`() = runTest {
        nextResponder = { req ->
            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(401)
                .message("Unauthorized")
                .body("unauthorized".toResponseBody("text/plain".toMediaType()))
                .build()
        }

        repository.ingestIncomingSms(
            listOf(JoinedSms("bKash", "Tk 300 TrxID RETRY1", 40_000L, simSlot = 1))
        )
        repository.processPendingQueue()

        val failedItem = repository.observeRecentSms(10).first().single()
        assertEquals(SmsStatus.FAILED_AUTH, failedItem.status)

        repository.retryItem(failedItem.id)
        nextResponder = { req ->
            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body("""{"ok":true,"status":"saved"}""".toResponseBody("application/json".toMediaType()))
                .build()
        }

        val retryOutcome = repository.processPendingQueue()
        assertEquals(QueueProcessingOutcome.ALL_DONE, retryOutcome)
        assertEquals(SmsStatus.SENT, repository.observeRecentSms(10).first().single().status)
    }

    @Test
    fun `sendTestWebhook sends bKash TEST payload and surfaces status code and body`() = runTest {
        nextResponder = { req ->
            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body("""{"ok":true,"status":"ignored"}""".toResponseBody("application/json".toMediaType()))
                .build()
        }

        val testResult = repository.sendTestWebhook(
            url = "http://127.0.0.1:25570/webhook/sms",
            secret = "my-secret"
        )

        assertTrue(testResult.isSuccess)
        assertEquals(200, testResult.statusCode)
        assertEquals("""{"ok":true,"status":"ignored"}""", testResult.body)

        val json = JSONObject(capturedBody)
        assertEquals("bKash", json.getString("from"))
        assertEquals("TEST", json.getString("text"))
    }
}
