package com.payforwarder.app

import android.content.Intent
import com.payforwarder.app.domain.ParsedSmsPart
import com.payforwarder.app.domain.SmsMessageParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SmsMessageParserTest {

    @Test
    fun `joins multipart SMS parts from same sender into single message`() {
        val parts = listOf(
            ParsedSmsPart(
                sender = "bKash",
                body = "You have received Tk 2,500.00 from 01711223344. ",
                timestampMillis = 1_700_000_001_000L
            ),
            ParsedSmsPart(
                sender = "bKash",
                body = "Fee Tk 0.00. Balance Tk 12,500.00. TrxID BK99X12345 at 22/11/2026 10:00",
                timestampMillis = 1_700_000_001_500L
            )
        )

        val joined = SmsMessageParser.joinMultipartParts(parts, simSlot = 2)

        assertEquals(1, joined.size)
        assertEquals("bKash", joined[0].sender)
        assertEquals(
            "You have received Tk 2,500.00 from 01711223344. Fee Tk 0.00. Balance Tk 12,500.00. TrxID BK99X12345 at 22/11/2026 10:00",
            joined[0].text
        )
        assertEquals(1_700_000_001_000L, joined[0].timestampMillis)
        assertEquals(2, joined[0].simSlot)
    }

    @Test
    fun `keeps parts from different senders separated`() {
        val parts = listOf(
            ParsedSmsPart("bKash", "Part 1 ", 1000L),
            ParsedSmsPart("NAGAD", "Cash In Tk 500 ", 2000L),
            ParsedSmsPart("bKash", "Part 2", 1005L),
            ParsedSmsPart("NAGAD", "TrxID NG7788", 2005L)
        )

        val joined = SmsMessageParser.joinMultipartParts(parts, simSlot = 1)

        assertEquals(2, joined.size)
        assertEquals("bKash", joined[0].sender)
        assertEquals("Part 1 Part 2", joined[0].text)
        assertEquals("NAGAD", joined[1].sender)
        assertEquals("Cash In Tk 500 TrxID NG7788", joined[1].text)
    }

    @Test
    fun `extracts SIM slot from direct extras and subscription resolver`() {
        val slot0Intent = Intent().putExtra("slot", 0)
        assertEquals(1, SmsMessageParser.extractSimSlot(slot0Intent))

        val slot1Intent = Intent().putExtra("android.telephony.extra.SLOT_INDEX", 1)
        assertEquals(2, SmsMessageParser.extractSimSlot(slot1Intent))

        val subIntent = Intent().putExtra("subscription", 42)
        assertEquals(
            2,
            SmsMessageParser.extractSimSlot(subIntent) { subId -> if (subId == 42) 1 else null }
        )

        assertNull(SmsMessageParser.extractSimSlot(Intent()))
    }
}
